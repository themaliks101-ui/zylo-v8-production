#!/bin/sh
npm install
export ZYLO_ADMIN_PASSWORD="${ZYLO_ADMIN_PASSWORD:-ChangeMe-123!}"
npm start
