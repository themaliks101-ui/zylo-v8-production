# ZYLO V8 — Mobile Admin + Production Database

Designed for: Android phone → Chrome → ZYLO website/admin.

Includes customer website, mobile admin panel, product CRUD, image uploads, pricing, categories, featured/visibility controls, enquiries, website settings, JSON backup, SQLite persistence, Render and Railway deployment files.

## Local test
Node.js 20+:
1. `npm install`
2. Set `ZYLO_ADMIN_PASSWORD`
3. `npm start`
4. Website: `http://localhost:3000`
5. Admin: `http://localhost:3000/admin.html`

Default password: `ChangeMe-123!` — change before deployment.

## Hosting
Deploy to a Node-compatible host. The host must provide persistent storage for `data/zylo.db` and `uploads/`, or these should be moved to managed database/object storage. Add HTTPS and a custom domain.

## Important
The starter catalogue still contains third-party visual reference images from the earlier demo. Replace them with ZYLO-owned/licensed photography before commercial use.

No online card payment is included yet; the current customer flow is catalogue + enquiry/WhatsApp.
