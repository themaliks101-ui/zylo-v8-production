
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ZYLO_ADMIN_PASSWORD || 'ChangeMe-123!';
const ROOT = __dirname;
const DATA = path.join(ROOT, 'data');
const UPLOADS = path.join(ROOT, 'uploads');
for (const d of [DATA, UPLOADS]) fs.mkdirSync(d,{recursive:true});
const db = new Database(path.join(DATA,'zylo.db'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS products(
id INTEGER PRIMARY KEY AUTOINCREMENT,cat TEXT,name TEXT,price REAL,old REAL,img TEXT,desc TEXT,source TEXT,url TEXT,
featured INTEGER DEFAULT 0,active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS enquiries(id TEXT PRIMARY KEY,created_at TEXT,name TEXT,phone TEXT,email TEXT,message TEXT,products TEXT,status TEXT DEFAULT 'New');`);
if(db.prepare('SELECT COUNT(*) n FROM products').get().n===0){
 const ins=db.prepare('INSERT INTO products(cat,name,price,old,img,desc,source,url,featured,active) VALUES(?,?,?,?,?,?,?,?,?,?)');
 const tx=db.transaction(rows=>rows.forEach(p=>ins.run(p.cat,p.name,p.price,p.old,p.img,p.desc,p.source,p.url,p.featured?1:0,p.active===false?0:1)));
 tx([{"id": 1, "cat": "Sofa", "name": "Cloud Curve L-Shape Sofa", "price": 189000, "old": 225000, "img": "https://images.unsplash.com/photo-1759722665610-e13e59aa117b?auto=format&fit=crop&q=88&w=1200", "desc": "Soft contemporary sectional with layered cushions and relaxed proportions.", "source": "Unsplash visual reference", "url": "https://unsplash.com/photos/a-modern-sectional-sofa-with-decorative-pillows-and-throw-YEH_y2VZiis", "featured": true, "active": true}, {"id": 2, "cat": "Sofa", "name": "Contemporary Modular Sectional", "price": 215000, "old": 255000, "img": "https://images.unsplash.com/photo-1767584394169-cb62eccfe930?auto=format&fit=crop&q=88&w=1200", "desc": "Modular seating direction for large living rooms and open-plan spaces.", "source": "Unsplash visual reference", "url": "https://unsplash.com/photos/a-modern-sofa-with-two-decorative-pillows-9bPQ8Qqz2bU", "featured": true, "active": true}, {"id": 3, "cat": "Sofa", "name": "Neutral Luxe Living Sofa", "price": 175000, "old": 210000, "img": "https://images.unsplash.com/photo-1615876234886-fd9a39fda97f?auto=format&fit=crop&q=88&w=1200", "desc": "Warm neutral upholstery concept with a premium residential feel.", "source": "Unsplash visual reference", "url": "https://unsplash.com/photos/brown-leather-sofa-with-gallery-wall-hWwP4LTGEQA", "featured": false, "active": true}, {"id": 4, "cat": "Bed", "name": "Plush Upholstered Statement Bed", "price": 95000, "old": 120000, "img": "https://images.unsplash.com/photo-1768946131535-b90bad125f16?auto=format&fit=crop&q=88&w=1200", "desc": "Soft upholstered bed direction with a calm, hotel-style bedroom palette.", "source": "Unsplash visual reference", "url": "https://unsplash.com/photos/a-modern-bed-with-plush-upholstery-and-white-linens-V2nVaXrbPv8", "featured": true, "active": true}, {"id": 5, "cat": "Bed", "name": "Modern Beige Platform Bed", "price": 88000, "old": 110000, "img": "https://images.unsplash.com/photo-1779903726446-6f796d533d47?auto=format&fit=crop&q=88&w=1200", "desc": "Minimal platform profile with floating bedside styling and neutral tones.", "source": "Unsplash visual reference", "url": "https://unsplash.com/photos/modern-bedroom-with-beige-bed-and-floating-white-nightstand-E-z8iE6LSgg", "featured": false, "active": true}, {"id": 6, "cat": "Chair", "name": "Modern Accent Lounge Chair", "price": 28000, "old": 36000, "img": "https://images.unsplash.com/photo-1758915753395-a5dddea1d813?auto=format&fit=crop&q=88&w=1200", "desc": "Compact sculptural chair for bedrooms, reading corners and living rooms.", "source": "Unsplash visual reference", "url": "https://unsplash.com/photos/modern-armchair-with-accent-pillow-and-side-table-EBhWu5w3dsI", "featured": false, "active": true}, {"id": 7, "cat": "Chair", "name": "Modern Armchair & Ottoman Set", "price": 42000, "old": 55000, "img": "https://images.unsplash.com/photo-1695457264636-f314b0027ca2?auto=format&fit=crop&q=88&w=1200", "desc": "Relaxed chair-and-footstool combination for premium lounge corners.", "source": "Unsplash visual reference", "url": "https://unsplash.com/photos/a-chair-and-ottoman-in-a-room-with-a-clock-N4uBSdrSvoA", "featured": false, "active": true}, {"id": 8, "cat": "Ottoman", "name": "Scandinavian Ottoman Lounge", "price": 18500, "old": 24000, "img": "https://images.unsplash.com/photo-1774477178005-bff823e43be8?auto=format&fit=crop&q=88&w=1200", "desc": "Soft, compact ottoman direction for flexible seating and foot support.", "source": "Unsplash visual reference", "url": "https://unsplash.com/photos/modern-armchair-and-ottoman-with-floor-lamp-by-window-SRZcOAERBUQ", "featured": false, "active": true}, {"id": 9, "cat": "Dining", "name": "Contemporary 6-Seater Dining Set", "price": 120000, "old": 150000, "img": "https://mobcenter.eu/cdn/shop/files/Nano_Banana_Pro_Modern_European_open_plan_dining_interior_with_a_contemporary_luxury_residential_sty.png?v=1772980417&width=1400", "desc": "Clean-lined dining table and upholstered chair direction for modern homes.", "source": "Web-store visual reference", "url": "https://mobcenter.eu/pages/bilbao-akcio", "featured": false, "active": true}, {"id": 10, "cat": "Dining", "name": "Minimal Upholstered Dining Chair", "price": 32000, "old": 42000, "img": "https://cdn.shopify.com/s/files/1/0298/1577/files/The_Best_Dining_Chairs_for_Singapore_Homes_480x480.webp?v=1728101801", "desc": "Comfort-focused dining chair direction with a light contemporary profile.", "source": "Web visual reference", "url": "https://www.prestige-affairs.com/blogs/how-to/the-best-dining-chairs-for-singapore-homes", "featured": false, "active": true}, {"id": 11, "cat": "Decor", "name": "Luxury Bedroom Feature Set", "price": 195000, "old": 240000, "img": "https://cdn.shopify.com/s/files/1/0692/9416/2159/files/nisara-luxury-yatak-odasi-takimi-1.jpg?v=1752481462", "desc": "Bedroom-set direction with geometric upholstery, integrated lighting and metallic details.", "source": "Web-store visual reference", "url": "https://sizindukkan.com/collections/luxury-yatak-odasi-takimlari", "featured": false, "active": true}, {"id": 12, "cat": "Decor", "name": "Blue Swivel Accent Set", "price": 45000, "old": 59000, "img": "https://target.scene7.com/is/image/Target/GUEST_4a13a68d-258c-41fa-869f-b4b88b85c635", "desc": "Compact swivel chair and matching ottoman concept for a reading nook.", "source": "Web-store visual reference", "url": "https://www.target.com/p/-/A-1008632984", "featured": false, "active": true}]);
}
if(db.prepare('SELECT COUNT(*) n FROM settings').get().n===0){
 const ins=db.prepare('INSERT INTO settings(key,value) VALUES(?,?)');
 for(const [k,v] of Object.entries({"brand": "ZYLO", "subtitle": "DECORS AND REAL ESTATE MANAGEMENT W.L.L.", "bahrainPhone": "+973 3365 8814", "whatsapp": "97333658814", "pakistanOffice": "Sector G-13, Islamabad", "bahrainOffice": "Tubli, Bahrain", "instagram": "zylo.bahrain", "facebook": "zylo", "email": "info@zylo.example", "heroTitle": "Modern Furniture. Interior Design. Real Estate Management.", "heroText": "Premium furniture concepts, custom interiors, renovation and property management for Bahrain and Pakistan.", "currencyBase": "PKR"})) ins.run(k,String(v));
}
function productsAll(all=false){
 const rows=db.prepare(all?'SELECT * FROM products ORDER BY id DESC':'SELECT * FROM products WHERE active=1 ORDER BY id DESC').all();
 return rows.map(p=>({...p,featured:!!p.featured,active:!!p.active}));
}
function settingsAll(){
 return Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value]));
}
app.use(express.json({limit:'2mb'}));
app.use(express.urlencoded({extended:true}));
app.use('/uploads', express.static(UPLOADS));
app.use(express.static(path.join(ROOT,'public')));

const sessions = new Map();
function read(name){ return JSON.parse(fs.readFileSync(path.join(DATA,name),'utf8')); }
function write(name,data){ fs.writeFileSync(path.join(DATA,name), JSON.stringify(data,null,2)); }
function auth(req,res,next){
  const sid=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('zylo_sid='))?.split('=')[1];
  if(!sid || !sessions.has(sid)) return res.status(401).json({error:'Unauthorized'});
  req.session=sessions.get(sid); next();
}

const storage=multer.diskStorage({
  destination:(req,file,cb)=>cb(null,UPLOADS),
  filename:(req,file,cb)=>{
    const ext=path.extname(file.originalname).toLowerCase() || '.jpg';
    cb(null, Date.now()+'-'+crypto.randomBytes(5).toString('hex')+ext);
  }
});
const upload=multer({storage,limits:{fileSize:8*1024*1024}});

app.post('/api/login',(req,res)=>{
  const {password}=req.body||{};
  if(password!==ADMIN_PASSWORD) return res.status(401).json({error:'Invalid password'});
  const sid=crypto.randomBytes(32).toString('hex');
  sessions.set(sid,{created:Date.now()});
  res.setHeader('Set-Cookie',`zylo_sid=${sid}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400`);
  res.json({ok:true});
});
app.post('/api/logout',auth,(req,res)=>{
  const sid=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('zylo_sid='))?.split('=')[1];
  if(sid) sessions.delete(sid);
  res.setHeader('Set-Cookie','zylo_sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  res.json({ok:true});
});
app.get('/api/me',auth,(req,res)=>res.json({ok:true}));

app.get('/api/products',(req,res)=>res.json(productsAll(false)));
app.get('/api/admin/products',auth,(req,res)=>res.json(productsAll(true)));

app.post('/api/admin/products',auth,(req,res)=>{
 const p=req.body||{};
 const r=db.prepare(`INSERT INTO products(cat,name,price,old,img,desc,source,url,featured,active)
 VALUES(?,?,?,?,?,?,?,?,?,?)`).run(String(p.cat||'Sofa'),String(p.name||'New Product'),Number(p.price||0),Number(p.old||0),
 String(p.img||''),String(p.desc||''),String(p.source||'ZYLO'),String(p.url||''),p.featured?1:0,p.active===false?0:1);
 res.json(productsAll(true).find(x=>x.id===r.lastInsertRowid));
});
app.put('/api/admin/products/:id',auth,(req,res)=>{
 const id=Number(req.params.id),p=req.body||{},old=db.prepare('SELECT * FROM products WHERE id=?').get(id);
 if(!old)return res.status(404).json({error:'Product not found'});
 db.prepare(`UPDATE products SET cat=?,name=?,price=?,old=?,img=?,desc=?,source=?,url=?,featured=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
 .run(p.cat??old.cat,p.name??old.name,Number(p.price??old.price),Number(p.old??old.old),p.img??old.img,p.desc??old.desc,p.source??old.source,p.url??old.url,
 p.featured===undefined?old.featured:(p.featured?1:0),p.active===undefined?old.active:(p.active?1:0),id);
 res.json(productsAll(true).find(x=>x.id===id));
});
app.delete('/api/admin/products/:id',auth,(req,res)=>{db.prepare('DELETE FROM products WHERE id=?').run(Number(req.params.id));res.json({ok:true});});
app.post('/api/admin/upload',auth,upload.single('image'),(req,res)=>{
 if(!req.file)return res.status(400).json({error:'No image uploaded'});
 res.json({url:'/uploads/'+req.file.filename,filename:req.file.filename});
});

app.get('/api/settings',(req,res)=>res.json(settingsAll()));
app.put('/api/settings',auth,(req,res)=>{
 const put=db.prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)');
 const tx=db.transaction(o=>Object.entries(o||{}).forEach(([k,v])=>put.run(k,String(v))));
 tx(req.body||{});res.json(settingsAll());
});

app.get('/api/admin/enquiries',auth,(req,res)=>res.json(db.prepare('SELECT * FROM enquiries ORDER BY created_at DESC').all()));
app.post('/api/enquiries',(req,res)=>{
 const e=req.body||{},id=crypto.randomUUID();
 db.prepare('INSERT INTO enquiries(id,created_at,name,phone,email,message,products,status) VALUES(?,?,?,?,?,?,?,?)')
 .run(id,new Date().toISOString(),e.name||'',e.phone||'',e.email||'',e.message||'',e.products||'New','New');
 res.json({ok:true,id});
});
app.put('/api/admin/enquiries/:id',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM enquiries WHERE id=?').get(req.params.id);
 if(!e)return res.status(404).json({error:'Enquiry not found'});
 db.prepare('UPDATE enquiries SET status=? WHERE id=?').run(String(req.body?.status||e.status),req.params.id);
 res.json(db.prepare('SELECT * FROM enquiries WHERE id=?').get(req.params.id));
});
app.get('/api/admin/backup',auth,(req,res)=>res.json({
 products:productsAll(true),settings:settingsAll(),enquiries:db.prepare('SELECT * FROM enquiries ORDER BY created_at DESC').all()
}));

app.get('/admin.html',(req,res)=>res.sendFile(path.join(ROOT,'public','admin.html')));
app.get('*',(req,res)=>{
  if(req.path.startsWith('/api/')) return res.status(404).end();
  res.sendFile(path.join(ROOT,'public','index.html'));
});

app.listen(PORT,()=>console.log(`ZYLO website running at http://localhost:${PORT}`));
