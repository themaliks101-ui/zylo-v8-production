@echo off
set /p ZYLO_ADMIN_PASSWORD=Enter admin password: 
call npm install
set ZYLO_ADMIN_PASSWORD=%ZYLO_ADMIN_PASSWORD%
npm start
